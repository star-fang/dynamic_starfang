package com.starfang.dynamics;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.Index;
import io.realm.annotations.PrimaryKey;

public class UnitTypes extends RealmObject {

    @PrimaryKey
    private int id;
    @Index
    private String name;
    private int aktLv;
    private int wisLv;
    private int defLv;
    private int agiLv;
    private int mrlLv;
    private RealmList<RealmInteger> unitPassiveListIds;
    private RealmList<RealmInteger> typePassiveIds;
    private RealmList<RealmInteger> gradeIds;
    private String name2;

}
