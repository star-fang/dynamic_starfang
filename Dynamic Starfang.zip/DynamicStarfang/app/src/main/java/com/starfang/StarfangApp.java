package com.starfang;

import android.app.Application;
import android.util.Log;

import com.starfang.dynamics.DynamicMigrations;

import io.realm.Realm;
import io.realm.RealmConfiguration;

public class StarfangApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
        try {
            RealmConfiguration migrationConfig = new RealmConfiguration.Builder().
                    name("realm.starfang").schemaVersion(0).migration(new DynamicMigrations()).build();
            Realm.setDefaultConfiguration(migrationConfig);
        } catch (IllegalStateException e ) {
            Log.e("FANG_APP",Log.getStackTraceString(e));
            RealmConfiguration newConfig = new RealmConfiguration.Builder()
                    .deleteRealmIfMigrationNeeded()
                    .build();
            Realm.setDefaultConfiguration(newConfig);
        }
    }

    @Override
    public void onTerminate() {
        Realm.getDefaultInstance().close();
        super.onTerminate();
    }
}
