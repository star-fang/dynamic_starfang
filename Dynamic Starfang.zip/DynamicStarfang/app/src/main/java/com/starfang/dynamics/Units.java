package com.starfang.dynamics;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.Index;
import io.realm.annotations.PrimaryKey;

public class Units extends RealmObject {

    @PrimaryKey
    private int id;
    @Index
    private String name;
    @Index
    private int unitTypeId;
    private String face;
    private String gender;
    @Index
    private int bannerId;
    @Index
    private int cost;
    private int str;
    private int intel;
    private int cmd;
    private int dex;
    private int lck;
    private RealmList<RealmInteger> passiveListIds;
    private int prefectId;
    private int warlordId;
    private String name2;
    private int hp;
    private int mp;
    private int ep;
    private int gold;

    private int statSum;

}
