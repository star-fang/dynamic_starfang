package com.starfang.dynamics;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import androidx.annotation.Nullable;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.RequestFuture;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import io.realm.Case;
import io.realm.Realm;

/*
MySQL <1> PHP <2> App <3> User
 <1> : Mysql tables interpreted by php and converted to Json form
 <2> : App download json and convert it to realm objects
 <3> : User can watch view by realm-adaptors
 */

public class DownloadJsonTask extends AsyncTask<String, String, String> {
    private static final String TAG = "FANG_DOWNLOAD";
    //private static final String DEFAULT_PHP_DIRECTORY = "/starfang/convertToRealm/";
    //private static final String DEFAULT_PHP_NAME = "convertToJSON.php";

    private static final int ECHO_UPDATE = 0;
    private static final int ECHO_LATEST = 1;
    private static final int ECHO_FAIL = -1;

    private static final String KEY_TABLE_NAME = "table_name";
    private static final String KEY_TABLE_COUNT= "table_count";

    private static final String KEY_ECHO = "echo";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_ARRAY = "array";

    private String url;
    private WeakReference<Context> contextWeakReference;

    interface PostCallback {
        void onSuccess(int echo, String message, JSONArray array, String tableName, long tableCount);
        void onError(String error);
    }

    public DownloadJsonTask(String url, Context context) {
        this.url = url;
        this.contextWeakReference = new WeakReference<>(context);
    }

    @Override
    protected String doInBackground(String... tableNames) {

        for (String tableName : tableNames) {


            postTable(
                    // Unit types => unit_types
                    tableName.replaceAll("\\s+","_").toLowerCase()
                    , new PostCallback() {
                @Override
                public void onSuccess(int echo, @Nullable String message, JSONArray array, String tableName, long tableCount) {

                    switch (echo) {
                        case ECHO_UPDATE:
                            ConvertToRealmTask convertToRealmTask = new ConvertToRealmTask(tableName, tableCount);
                            convertToRealmTask.doInBackground();
                            publishProgress("갱신",message);
                            break;
                        case ECHO_LATEST:
                            publishProgress("최신",message);
                            break;
                        case ECHO_FAIL:
                            publishProgress("서버 에러",message);
                            break;
                        default:
                    }
                }

                @Override
                public void onError(String error) {
                    publishProgress("에러 발생",error);
                }
            });

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Log.e(TAG, Log.getStackTraceString(e));
                Thread.currentThread().interrupt();
            }


        }

        return null;
    }

    @Override
    protected void onProgressUpdate(String... values) {

    }

    private void postTable(final String tableName, PostCallback callback) {

        RequestQueue requestQueue = Volley.newRequestQueue(contextWeakReference.get());
        RequestFuture<JSONObject> requestFuture = RequestFuture.newFuture();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.POST, url, null,
                requestFuture, requestFuture) {
            @Override
            public Map<String, String> getHeaders() {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json; charset=utf-8");
                return headers;
            }

            @Override
            public Map<String, String> getParams() {
                HashMap<String, String> params = new HashMap<>();
                params.put(KEY_TABLE_NAME, tableName);
                params.put(KEY_TABLE_COUNT,getTableCount(tableName));
                return params;
            }
        };

        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                6000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        requestQueue.add(jsonObjectRequest);

        try {
            JSONObject jsonObject = requestFuture.get(20, TimeUnit.SECONDS);
            callback.onSuccess(
                    jsonObject.getInt(KEY_ECHO),
                    jsonObject.getString(KEY_MESSAGE),
                    jsonObject.getJSONArray(KEY_ARRAY),
                    jsonObject.getString(KEY_TABLE_NAME).replaceAll("\\s+","_").toLowerCase(),
                    jsonObject.getLong(KEY_TABLE_COUNT)
                    );
        } catch (InterruptedException | TimeoutException | ExecutionException | JSONException e) {
            callback.onError(e.getClass().getSimpleName());
        }
    }

    private String getTableCount(String tableName) {

        long count = 0L;

        Realm realm = Realm.getDefaultInstance();
        try {
            History history = realm.where(History.class)
                    .equalTo(History.FIELD_TABLE,tableName, Case.INSENSITIVE).findFirst();
            if (history != null) {
                count = history.getTableCount();
            }
        } catch (RuntimeException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        } finally {
            realm.close();
            Log.d(TAG, "realm instance closed");
        }

        return String.valueOf(count);
    }


}
