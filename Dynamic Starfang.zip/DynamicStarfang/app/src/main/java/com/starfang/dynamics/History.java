package com.starfang.dynamics;

import io.realm.RealmObject;

public class History extends RealmObject {

    static final String FIELD_TABLE = "tableName";
    static final String FIELD_COUNT = "tableCount";

    private String tableName;
    private long tableCount;

    public void setTableName( String name ) {
        this.tableName = name;
    }

    public void setTableCount( long count ) {
        this.tableCount = count;
    }

    public long getTableCount() {
        return tableCount;
    }
}
